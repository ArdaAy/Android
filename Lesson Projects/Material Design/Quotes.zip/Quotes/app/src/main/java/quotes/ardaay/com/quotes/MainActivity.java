package quotes.ardaay.com.quotes;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements OnClickListener{
    private Button btn;
    private TextView txt;
    private QuoteServer qs;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        qs = new QuoteServer();
        btn = (Button) findViewById(R.id.btnQuote);
        txt = (TextView) findViewById(R.id.txtQuote);
        txt.setText(qs.getRandomQuote());
        btn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v == btn){
            txt.setText(qs.getRandomQuote());
        }
    }
}
